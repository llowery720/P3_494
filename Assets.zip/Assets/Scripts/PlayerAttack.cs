﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttack : MonoBehaviour
{
	public GameObject projectile;
	public Transform firePoint;
	public float force = 60.0f;
    // Start is called before the first frame update
    void Start()
    {
        firePoint = this.gameObject.transform.GetChild(0);
    }

    // Update is called once per frame
    void Update()
    {
    	if (Input.GetKeyDown(KeyCode.X)){
        	GameObject shot = Instantiate(projectile, firePoint.position, firePoint.rotation);
    		//shot.transform.Rotate(0,0,90);
    		Rigidbody rb = shot.GetComponent<Rigidbody>();
    		rb.AddForce(firePoint.right * force);
    	}
    }
}
