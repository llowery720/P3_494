﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHealth : MonoBehaviour
{
	public float health;
	public int playerNumber;
    // Start is called before the first frame update
    void Start()
    {
        health = 20f;
    }


    private void OnTriggerEnter(Collider other) {
     	if (other.tag == "Bullet"){
            health -= 10;
            if (health <= 0){
                this.gameObject.SetActive(false);
                //Add other game over stuff
            }
        }      
        //this is where healthpickups etc go  


    }
}
